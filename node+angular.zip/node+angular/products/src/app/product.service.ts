import { Injectable } from '@angular/core';
import { IProduct } from './Component/product-list/product.model';
import { HttpClient,HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  getProducts(){
   return (this.http.get("http://localhost:3000/products"));
  //  .subscribe((data)=>{
  //     return console.log(data);
  //   });
  } 
  newProduct(item){
    return this.http.post("http://localhost:3000/insert",{"product":item})
    .subscribe(data =>{
      console.log(data)
    }) 
  }


  constructor(private http:HttpClient) { }
}
