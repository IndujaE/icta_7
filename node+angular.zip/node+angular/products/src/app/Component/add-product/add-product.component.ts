import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../product.service';
import { IProduct } from '../product-list/product.model';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  page_title:String ="Add Products";


  constructor(private productservice:ProductService) { }

  productItem = new IProduct(null,null,null,null,null,null,null,null);


  ngOnInit() {
  }
  AddProduct(){
    this.productservice.newProduct(this.productItem);
    console.log(this.productItem);
    alert("sucess");
  }

}
