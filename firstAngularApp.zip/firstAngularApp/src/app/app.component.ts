import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',//linked template
  // template: '<p>welcome to {{title}}</p>',//inline template
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ICT Academy';
  name ='Induja'
}
