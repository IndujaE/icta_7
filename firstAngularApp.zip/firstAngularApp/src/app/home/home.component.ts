import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title:String = "My home page"
  name:String = "Induja"

  products:any[] =[
    {
      "productid":1,
      "productname":"Testing product 1",
      "productcode":"p1"
    },
    {
      "productid":2,
      "productname":"Testing product 2",
      "productcode":"p2"
    },
    {
      "productid":3,
      "productname":"Testing product 3",
      "productcode":"p3"
    },
  ]
  

  constructor() { }

  ngOnInit() {
  }

}
