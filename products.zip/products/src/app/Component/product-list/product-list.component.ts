import { Component, OnInit } from '@angular/core';
import { IProduct } from './product.model';
import { ProductService } from '../../product.service';


@Component({
  providers:[ProductService],
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  page_title:String="Product List";

  products: IProduct[];
  showimage : boolean = false;
  toggleimage():void{
    this.showimage=!this.showimage;
  }  
  

  constructor( private productserviceobject:ProductService) { }

  ngOnInit():void {
    this.products=this.productserviceobject.getProducts();
  }

}
