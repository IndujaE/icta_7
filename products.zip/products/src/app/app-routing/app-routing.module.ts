import { NgModule } from '@angular/core';

import {Routes,RouterModule} from '@angular/router';
import { ProductListComponent } from '../Component/product-list/product-list.component';
import { AddProductComponent } from '../Component/add-product/add-product.component';

const routes:Routes=[
  {path:'',component:ProductListComponent},
  {path:'add',component:AddProductComponent}
];

@NgModule({
  imports: [
   RouterModule.forRoot(routes)
  ],
  exports : [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
