const exp=require("express");

const booksRouter=exp.Router();

function Router(nav){

var book_details=[
    {title :'book1',genre:'drama',author:'ghi'},
    {title :'book2',genre:'fiction',author:'zxc'},
    {title :'book3',genre:'novel',author:'bnm'},
    {title :'book4',genre:'fiction',author:'mnb'},
    {title :'book5',genre:'novel',author:'oiu'}
]

booksRouter.route('/').get((req,res)=>{
   // res.send("hello books");


   res.render('books' ,{
    title:"Book Details",
    nav,
    book_details 
   
});

});
booksRouter.route('/:id').get((req,res)=>{
   // res.send("hello single book");
   const id=req.params.id;
   var k=parseInt(id)+1;
   res.render('book' ,{
    title:"Book Details",
    nav,
    book:book_details[id],
    k
   });
});
return booksRouter;
}
// module.exports=booksRouter;
module.exports=Router;

