const exp=require("express");

const aboutRouter=exp.Router();

var description={ des : 'qwerttyyyuioplkkkkkkjhgfdsazxcvbbbbbbbbbnm'};



function router(nav){

    

    aboutRouter.route('/').get((req,res)=>{
        res.render('about',{
            title:"About",
            nav,
            description

        });
    });


    return aboutRouter;
}

module.exports=router;