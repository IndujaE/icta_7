const exp=require("express");

const contactRouter=exp.Router();


function router(nav){

var cont ={
    name : 'Induja',
    phone_number : 9800768987
}

    contactRouter.route('/').get((req,res)=>{
        res.render('contact',{
            title:"Contact",
            nav,
            cont
        });
    });


    return contactRouter;
}
module.exports=router;