const exp=require("express");

const AuthorRouter=exp.Router();

function router(nav){
var author_details=[
    {name:'ghi',place:'place:USA'},
    {name:'zxc',place:'place:UK'},
    {name:'bnm',place:'place:INDIA'},
    {name:'mnb',place:'place:CHINA'},
    {name:'oiu',place:'place:LONDON'}
]


AuthorRouter.route('/')
.get((req,res)=>{
    // res.send("hello author");

    res.render('authors' ,{
        title:"Author Details",
        nav,
        author_details 
    });
});

AuthorRouter.route('/:id')
.get((req,res)=>{
    //res.send("hello single author");
    const id=req.params.id;
    res.render('author',{
        title:"Author Details",
        nav,
        author:author_details[id] 

    })

});
return AuthorRouter;
}

//module.exports=AuthorRouter;
module.exports=router;