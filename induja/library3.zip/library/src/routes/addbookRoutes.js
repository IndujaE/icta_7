const exp=require("express");

const addbookRouter=exp.Router();


function router(nav){


    addbookRouter.route('/').get((req,res)=>{
        res.render('add_book',{
            title:"Add Book",
            nav
            
        });
    });


    return addbookRouter;
}
module.exports=router;