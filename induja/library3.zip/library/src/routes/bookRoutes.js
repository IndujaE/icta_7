const exp=require("express");
//const mongoose=require("mongoose");
const book_data=require("../model/book_data");

const booksRouter=exp.Router();


function Router(nav){


booksRouter.route('/').get((req,res)=>{
   // res.send("hello books");

    book_data.find().then(function(book_details){
        res.render('books' ,{
            title:"Book Details",
            nav,
            book_details
           
        });

    });
   

});
booksRouter.route('/:id').get((req,res)=>{
   // res.send("hello single book");
   const id=req.params.id;
  // var k=parseInt(id)+1;
   book_data.findOne({_id:id}).then(function(book_details){
    res.render('book' ,{
        title:"Book Details",
        nav,
        book_details
       // k
       });
   })
   
});
return booksRouter;
}
// module.exports=booksRouter;
module.exports=Router;

