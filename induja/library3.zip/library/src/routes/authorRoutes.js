const exp=require("express");

const author_data=require("../model/author_data");
const AuthorRouter=exp.Router();

function router(nav){



AuthorRouter.route('/').get((req,res)=>{
    // res.send("hello author");
    author_data.find().then(function(author_details){
        res.render('authors' ,{
            title:"Author Details",
            nav,
            author_details 
        });

    });
   
});

AuthorRouter.route('/:id').get((req,res)=>{
    //res.send("hello single author");
    const id=req.params.id;
    author_data.findOne({_id:id}).then(function(author){
        res.render('author',{
            title:"Author Details",
            nav,
            author 
    
        });
    });
   

});
return AuthorRouter;
}

//module.exports=AuthorRouter;
module.exports=router;