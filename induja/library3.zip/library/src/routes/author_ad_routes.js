const exp=require("express");
const authordata=require("../model/author_data");

const auth_adminRouter=exp.Router();

function router(nav){
    auth_adminRouter.route('/').get((req,res)=>{
        res.render('add_author',{
            title:"Add Author",
            nav
            
        });
    });

auth_adminRouter.route('/add').get((req,res)=>{
    // res.send("inserting books")
    var item={
        name:req.param("aname"),
        place:req.param('place'),
        book_no:req.param('book_no')
    }
    var book= new authordata(item);
    book.save();
    res.redirect("/authors");
});


return auth_adminRouter;
}
module.exports=router;