const exp=require("express");
const bookdata=require("../model/book_data");

const adminRouter=exp.Router();



function router(nav){


    adminRouter.route('/').get((req,res)=>{
        res.render('add_book',{
            title:"Add Book",
            nav
            
        });
    });
    adminRouter.route('/add').get((req,res)=>{
        // res.send("inserting books")
        var item={
            title:req.param.bname,
            author:req.param('author'),
            genre:req.param('genre')
        }
        var book= new bookdata(item);
        book.save();
        res.redirect("/books");
    });


    return adminRouter;
}
module.exports=router;