const mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/librarydb");

const Schema=mongoose.Schema;

var new_model_schema=new Schema(
    {
        title:String,
        author:String,
        genre:String

    }
);

var book_data=mongoose.model("book-data",new_model_schema);

module.exports=book_data;
