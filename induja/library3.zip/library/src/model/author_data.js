const mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/librarydb");

const Schema=mongoose.Schema;

var new_model_schema=new Schema(
    {
        name:String,
        place:String,
        book_no:Number

    }
);

var author_data=mongoose.model("author-data",new_model_schema);

module.exports=author_data;
