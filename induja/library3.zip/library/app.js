const exp=require("express");
const chalk=require("chalk");
const path=require("path");


const nav=[
    {link:'/books',title:'BOOKS'},
    {link:'/authors',title:'AUTHORS'},
    {link:'/about',title:'ABOUT US'},
    {link:'/contact',title:'CONTACT US'},
    {link:'/admin',title:'ADD BOOK'},
    {link:'/auth_admin',title:'ADD AUTHOR'}
]


const booksRouter=require("./src/routes/bookRoutes")(nav);
const authorsRouter=require("./src/routes/authorRoutes")(nav);
const aboutRouter=require("./src/routes/aboutRoutes")(nav);
const contactRouter=require("./src/routes/contactRoutes")(nav);
const addRouter=require("./src/routes/addbookRoutes")(nav);
const adminRouter=require("./src/routes/adminRoutes")(nav);
const author_adminRouter=require("./src/routes/author_ad_routes")(nav);


var app=new exp();


app.use(exp.static(path.join(__dirname,"/public")));
// app.get('/',function(req,res){
//     //res.send("hello from library app");
//     //res.sendFile(__dirname+"/views/index.html");
//     res.sendFile(path.join(__dirname,"/views/index.html"));
// });

app.set('views','./src/views');
app.set('view engine','ejs');
// app.get('/',function(req,res){
//     res.render('index');
// });



app.get('/',function(req,res){
    res.render('index',{
            title:"Library",
            //list:['book1','book2','book3']
            nav
    });
                
});

app.use('/books',booksRouter);

app.use('/authors',authorsRouter);

app.use('/about',aboutRouter);

app.use('/contact',contactRouter);

app.use('/add_book',addRouter);

app.use('/admin',adminRouter);

app.use('/auth_admin',author_adminRouter);





app.listen(3000,function(){
    console.log("listening to port"+chalk.red(3000))
});